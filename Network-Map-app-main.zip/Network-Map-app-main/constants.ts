
import { NetworkType } from './types';

export const NETWORK_TYPES: NetworkType[] = [
  { id: '5G', label: '5G' },
  { id: '4G', label: '4G / LTE' },
  { id: 'Fiber', label: 'Fiber' },
  { id: 'Cable', label: 'Cable' },
  { id: 'Satellite', label: 'Satellite' },
  { id: '3G', label: '3G' },
  { id: '2G', label: '2G' },
];
