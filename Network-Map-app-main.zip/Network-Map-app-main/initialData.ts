import { CoverageData } from './types';

// This data uses ISO 3166-1 numeric country codes as strings.
export const INITIAL_COVERAGE_DATA: CoverageData = [
  // 5G Data for default selected networks
  { country: '840', networkType: '5G', throughputScore: 85 }, // USA
  { country: '410', networkType: '5G', throughputScore: 95 }, // South Korea
  { country: '156', networkType: '5G', throughputScore: 90 }, // China
  { country: '276', networkType: '5G', throughputScore: 82 }, // Germany
  { country: '826', networkType: '5G', throughputScore: 80 }, // UK
  { country: '392', networkType: '5G', throughputScore: 88 }, // Japan
  { country: '124', networkType: '5G', throughputScore: 78 }, // Canada
  { country: '036', networkType: '5G', throughputScore: 75 }, // Australia
  { country: '752', networkType: '5G', throughputScore: 85 }, // Sweden
  { country: '756', networkType: '5G', throughputScore: 87 }, // Switzerland
  { country: '356', networkType: '5G', throughputScore: 60 }, // India
  { country: '076', networkType: '5G', throughputScore: 55 }, // Brazil
  { country: '710', networkType: '5G', throughputScore: 50 }, // South Africa
  { country: '566', networkType: '5G', throughputScore: 30 }, // Nigeria
  { country: '250', networkType: '5G', throughputScore: 79 }, // France
  { country: '380', networkType: '5G', throughputScore: 75 }, // Italy
  { country: '724', networkType: '5G', throughputScore: 77 }, // Spain
  { country: '643', networkType: '5G', throughputScore: 45 }, // Russia

  // 4G Data for default selected networks
  { country: '840', networkType: '4G', throughputScore: 92 }, // USA
  { country: '410', networkType: '4G', throughputScore: 98 }, // South Korea
  { country: '156', networkType: '4G', throughputScore: 94 }, // China
  { country: '276', networkType: '4G', throughputScore: 90 }, // Germany
  { country: '826', networkType: '4G', throughputScore: 88 }, // UK
  { country: '392', networkType: '4G', throughputScore: 96 }, // Japan
  { country: '124', networkType: '4G', throughputScore: 89 }, // Canada
  { country: '036', networkType: '4G', throughputScore: 87 }, // Australia
  { country: '752', networkType: '4G', throughputScore: 95 }, // Sweden
  { country: '756', networkType: '4G', throughputScore: 94 }, // Switzerland
  { country: '356', networkType: '4G', throughputScore: 80 }, // India
  { country: '076', networkType: '4G', throughputScore: 78 }, // Brazil
  { country: '710', networkType: '4G', throughputScore: 75 }, // South Africa
  { country: '566', networkType: '4G', throughputScore: 65 }, // Nigeria
  { country: '250', networkType: '4G', throughputScore: 91 }, // France
  { country: '380', networkType: '4G', throughputScore: 88 }, // Italy
  { country: '724', networkType: '4G', throughputScore: 90 }, // Spain
  { country: '643', networkType: '4G', throughputScore: 82 }, // Russia
  { country: '484', networkType: '4G', throughputScore: 79 }, // Mexico
  { country: '032', networkType: '4G', throughputScore: 75 }, // Argentina
  { country: '818', networkType: '4G', throughputScore: 70 }, // Egypt
  { country: '704', networkType: '4G', throughputScore: 85 }, // Vietnam
];
