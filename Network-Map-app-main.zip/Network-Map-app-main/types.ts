
export interface NetworkType {
  id: string;
  label: string;
}

export interface CoverageDataPoint {
  country: string; // ISO 3166-1 numeric code as a string
  networkType: string;
  throughputScore: number; // 1-100
}

export interface TooltipData {
  x: number;
  y: number;
  countryName: string;
  score: number | null;
}

export type CoverageData = CoverageDataPoint[];

export interface CountryInfo {
  id: string;
  name: string;
}