import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Header from './components/Header';
import Controls from './components/Controls';
import WorldMap from './components/Map';
import Loader from './components/Loader';
import Tooltip from './components/Tooltip';
import { generateCoverageData } from './services/geminiService';
import { CoverageData, TooltipData, CountryInfo } from './types';
import { NETWORK_TYPES } from './constants';
import { INITIAL_COVERAGE_DATA } from './initialData';

declare const topojson: any;

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [coverageData, setCoverageData] = useState<CoverageData>(INITIAL_COVERAGE_DATA);
  const [selectedNetworks, setSelectedNetworks] = useState<Set<string>>(
    new Set([NETWORK_TYPES[0].id, NETWORK_TYPES[1].id])
  );
  const [tooltipData, setTooltipData] = useState<TooltipData | null>(null);
  const [countries, setCountries] = useState<CountryInfo[]>([]);

  useEffect(() => {
    // Fetch and parse country names from the same TopoJSON file
    fetch('https://unpkg.com/world-atlas@2.0.2/countries-110m.json')
      .then(response => response.json())
      .then(world => {
        const land = topojson.feature(world, world.objects.countries);
        const countryInfos = land.features.map((d: any) => ({
          id: d.id,
          name: d.properties.name,
        }));
        setCountries(countryInfos);
      })
      .catch(error => console.error("Error loading country data:", error));
  }, []);

  const fetchData = useCallback(async (networksToFetch: string[]) => {
    if (networksToFetch.length === 0) {
      // setCoverageData([]); // We don't want to clear all data
      return;
    }
    
    setIsLoading(true);
    setLoadingMessage(`Generating AI data for ${networksToFetch.length} network type(s)...`);
    
    const newCoverageData = await generateCoverageData(networksToFetch);
    
    setCoverageData(prevData => {
        const otherNetworkData = prevData.filter(d => !networksToFetch.includes(d.networkType));
        return [...otherNetworkData, ...newCoverageData];
    });

    setIsLoading(false);
    setLoadingMessage('');
  }, []);

  useEffect(() => {
    const networksToFetch = Array.from(selectedNetworks).filter(networkId => 
      !coverageData.some(d => d.networkType === networkId)
    );

    if(networksToFetch.length > 0) {
        fetchData(networksToFetch);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedNetworks, fetchData]);


  const handleNetworkChange = (networkId: string) => {
    setSelectedNetworks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(networkId)) {
        newSet.delete(networkId);
      } else {
        newSet.add(networkId);
      }
      return newSet;
    });
  };

  const handleHover = useCallback((data: TooltipData | null) => {
    setTooltipData(data);
  }, []);

  const memoizedWorldMap = useMemo(() => (
    <WorldMap 
        coverageData={coverageData} 
        selectedNetworks={selectedNetworks} 
        onHover={handleHover}
        countries={countries}
    />
  ), [coverageData, selectedNetworks, handleHover, countries]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-gray-800">
      <Header />
      <Controls
        selectedNetworks={selectedNetworks}
        onNetworkChange={handleNetworkChange}
        isLoading={isLoading}
      />
      <main className="w-full h-full">
        {memoizedWorldMap}
      </main>
      {isLoading && <Loader message={loadingMessage} />}
      <Tooltip data={tooltipData} />
    </div>
  );
};

export default App;