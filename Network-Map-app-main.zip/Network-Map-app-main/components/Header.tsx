
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="absolute top-0 left-0 w-full p-4 z-20 pointer-events-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl md:text-3xl font-bold text-white drop-shadow-lg">
          Global Network Coverage
        </h1>
        <p className="text-sm md:text-base text-gray-300 drop-shadow-md">
          AI-generated visualization of worldwide network throughput
        </p>
      </div>
    </header>
  );
};

export default Header;
