
import React from 'react';
import { NetworkType } from '../types';
import { NETWORK_TYPES } from '../constants';

interface ControlsProps {
  selectedNetworks: Set<string>;
  onNetworkChange: (networkId: string) => void;
  isLoading: boolean;
}

const Controls: React.FC<ControlsProps> = ({ selectedNetworks, onNetworkChange, isLoading }) => {
  return (
    <div className="absolute top-24 left-0 p-4 z-20">
      <div className="bg-gray-800 bg-opacity-70 backdrop-blur-sm rounded-lg shadow-2xl p-4 w-64">
        <h3 className="text-white font-bold text-lg mb-3 border-b border-gray-600 pb-2">Network Layers</h3>
        <div className="space-y-3">
          {NETWORK_TYPES.map((network: NetworkType) => (
            <label key={network.id} className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                className="h-5 w-5 rounded bg-gray-700 border-gray-600 text-cyan-500 focus:ring-cyan-600 focus:ring-2 disabled:opacity-50"
                checked={selectedNetworks.has(network.id)}
                onChange={() => onNetworkChange(network.id)}
                disabled={isLoading}
              />
              <span className={`text-gray-200 ${isLoading ? 'opacity-50' : ''}`}>{network.label}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Controls;
