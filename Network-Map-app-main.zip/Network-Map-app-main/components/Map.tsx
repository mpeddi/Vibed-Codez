import React, { useEffect, useRef, useMemo } from 'react';
import { CountryInfo, CoverageData, TooltipData } from '../types';

declare const d3: any;
declare const topojson: any;

interface WorldMapProps {
  coverageData: CoverageData;
  selectedNetworks: Set<string>;
  onHover: (tooltipData: TooltipData | null) => void;
  countries: CountryInfo[];
}

const WorldMap: React.FC<WorldMapProps> = ({ coverageData, selectedNetworks, onHover, countries }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const worldAtlasUrl = 'https://unpkg.com/world-atlas@2.0.2/countries-110m.json';

  const countryScores = useMemo(() => {
    const scores = new Map<string, { totalScore: number; count: number }>();
    if (selectedNetworks.size === 0) return new Map<string, number>();

    coverageData
      .filter(d => selectedNetworks.has(d.networkType))
      .forEach(d => {
        const countryData = scores.get(d.country) || { totalScore: 0, count: 0 };
        countryData.totalScore += d.throughputScore;
        countryData.count += 1;
        scores.set(d.country, countryData);
      });

    const avgScores = new Map<string, number>();
    scores.forEach((value, key) => {
      avgScores.set(key, value.totalScore / value.count);
    });
    return avgScores;
  }, [coverageData, selectedNetworks]);
  
  const colorScale = useMemo(() => {
    return d3.scaleSequential(d3.interpolateCool).domain([1, 100]);
  }, []);

  useEffect(() => {
    if (!svgRef.current || countries.length === 0) return;
    
    const svg = d3.select(svgRef.current);
    const { width, height } = svg.node().getBoundingClientRect();
    const projection = d3.geoMercator().scale(width / 2 / Math.PI).translate([width / 2, height / 1.5]);
    const path = d3.geoPath().projection(projection);
    
    const countryNameMap = new Map(countries.map(c => [c.id, c.name]));

    d3.json(worldAtlasUrl).then((world: any) => {
      const land = topojson.feature(world, world.objects.countries);

      const countryPaths = svg.selectAll('.country')
        .data(land.features, (d: any) => d.id);
      
      countryPaths.enter()
        .append('path')
        .attr('class', 'country')
        .attr('d', path)
        .attr('stroke', '#1a202c') // gray-900
        .attr('stroke-width', 0.5)
        .on('mouseover', (event: MouseEvent, d: any) => {
          d3.select(event.currentTarget).attr('stroke', '#63B3ED'); // blue-300
          const score = countryScores.get(d.id) ?? null;
          onHover({
            x: event.pageX,
            y: event.pageY,
            countryName: countryNameMap.get(d.id) || 'Unknown',
            score: score,
          });
        })
        .on('mouseout', (event: MouseEvent) => {
          d3.select(event.currentTarget).attr('stroke', '#1a202c');
          onHover(null);
        })
        .merge(countryPaths)
        .transition()
        .duration(300)
        .attr('fill', (d: any) => {
          const score = countryScores.get(d.id);
          return score ? colorScale(score) : '#4A5568';
        });

      countryPaths.exit().remove();
    });

    if (!svg.property('__zoom_initialized__')) {
      const zoom = d3.zoom()
        .scaleExtent([1, 8])
        .on('zoom', (event: any) => {
          svg.selectAll('.country').attr('transform', event.transform);
        });
      svg.call(zoom);
      svg.property('__zoom_initialized__', true);
    }
  }, [countryScores, colorScale, onHover, countries]);

  return <svg ref={svgRef} className="w-full h-full cursor-grab"></svg>;
};

export default WorldMap;