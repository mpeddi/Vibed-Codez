
import React from 'react';
import { TooltipData } from '../types';

interface TooltipProps {
  data: TooltipData | null;
}

const Tooltip: React.FC<TooltipProps> = ({ data }) => {
  if (!data) return null;

  const { x, y, countryName, score } = data;

  return (
    <div
      className="absolute bg-gray-800 text-white text-sm rounded-md shadow-lg px-3 py-2 pointer-events-none transition-opacity duration-200 z-30"
      style={{
        left: `${x + 15}px`,
        top: `${y + 15}px`,
      }}
    >
      <p className="font-bold text-base">{countryName}</p>
      {score !== null ? (
        <div className="flex items-center mt-1">
          <span className="text-gray-400 mr-2">Avg. Throughput:</span>
          <span className="font-semibold text-cyan-300">{score.toFixed(1)} / 100</span>
        </div>
      ) : (
        <p className="text-gray-400 italic mt-1">No data available</p>
      )}
    </div>
  );
};

export default Tooltip;
