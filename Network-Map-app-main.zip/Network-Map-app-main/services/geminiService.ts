
import { GoogleGenAI, Type } from "@google/genai";
import { CoverageData } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateCoverageData = async (networkTypes: string[]): Promise<CoverageData> => {
  if (networkTypes.length === 0) {
    return [];
  }
  
  const prompt = `
    Generate a JSON array representing global network coverage data for the following network types: ${networkTypes.join(', ')}.
    For each object in the array, provide a 'country' (using ISO 3166-1 numeric country code as a string), a 'networkType', and a 'throughputScore' from 1 (very low) to 100 (very high).
    Provide at least 300 data points, covering a wide range of countries and all requested network types.
    Ensure the data reflects realistic global disparities in network infrastructure. For example, developed nations should have higher scores for 5G and Fiber, while developing regions might have stronger 2G/3G coverage but lower scores for newer technologies.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              country: {
                type: Type.STRING,
                description: 'The ISO 3166-1 numeric code of the country as a string.',
              },
              networkType: {
                type: Type.STRING,
                description: 'The type of network.',
              },
              throughputScore: {
                type: Type.INTEGER,
                description: 'A score from 1 to 100 representing network throughput.',
              },
            },
            required: ["country", "networkType", "throughputScore"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const parsedData = JSON.parse(jsonText);
    
    // Basic validation
    if (Array.isArray(parsedData)) {
      return parsedData.filter(item => 
        item && typeof item.country === 'string' && 
        typeof item.networkType === 'string' && 
        typeof item.throughputScore === 'number'
      );
    }
    return [];

  } catch (error) {
    console.error("Error generating coverage data from Gemini:", error);
    // In case of error, you might want to return some mock data or an empty array
    return [];
  }
};