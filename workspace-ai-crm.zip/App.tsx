
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { User, Contact, Email } from './types';
import { ContactTable } from './components/ContactTable';
import { SummaryModal } from './components/SummaryModal';
import { generateContactSummary } from './services/geminiService';
import { LoginScreen } from './components/LoginScreen';
import { Header } from './components/Header';
import * as GoogleWorkspaceService from './services/googleWorkspaceService';
import { getUserRole } from './config/accessControl';

const App: React.FC = () => {
    const [gapiReady, setGapiReady] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [users, setUsers] = useState<User[]>([]);
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [allContacts, setAllContacts] = useState<Contact[]>([]);
    const [activeUserId, setActiveUserId] = useState<string>('all');
    const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
    const [summaries, setSummaries] = useState<Record<string, string>>({});
    const [isSummaryLoading, setIsSummaryLoading] = useState<boolean>(false);
    const [summaryError, setSummaryError] = useState<string | null>(null);
    const [appError, setAppError] = useState<string | null>(null);
    const [isLoadingData, setIsLoadingData] = useState(false);

    useEffect(() => {
        const initGapi = async () => {
            try {
                await GoogleWorkspaceService.initClient((authResult) => {
                    if ('access_token' in authResult && authResult.access_token) {
                        setIsLoggedIn(true);
                    } else {
                        setIsLoggedIn(false);
                        setCurrentUser(null);
                    }
                });
                setGapiReady(true);
            } catch (error) {
                console.error("Error initializing GAPI client:", error);
                if (error instanceof Error) {
                    setAppError(error.message);
                } else {
                    setAppError("Could not initialize Google services. Please check your configuration and refresh the page.");
                }
            }
        };
        initGapi();
    }, []);

    useEffect(() => {
        if (!isLoggedIn || !gapiReady) return;

        const fetchWorkspaceData = async () => {
            setIsLoadingData(true);
            setAppError(null);
            try {
                // Determine the current user and their role first
                const loggedInUserEmail = GoogleWorkspaceService.getCurrentUserEmail();
                const userRole = getUserRole(loggedInUserEmail);

                if (!userRole) {
                    setAppError("Access Denied. You do not have permission to use this application. Please contact your administrator.");
                    setIsLoadingData(false);
                    return;
                }

                const workspaceUsers = await GoogleWorkspaceService.getUsers();
                const mappedUsers: User[] = workspaceUsers.map(u => ({...u, role: getUserRole(u.email) }));
                setUsers(mappedUsers);
                
                const loggedInUserFromList = mappedUsers.find(u => u.email === loggedInUserEmail) || null;
                setCurrentUser(loggedInUserFromList);

                if (loggedInUserFromList) {
                    // Default view to the user's own contacts
                    setActiveUserId(loggedInUserFromList.id);
                }
                
                // Fetch emails based on user role
                let usersToFetchFor: User[];
                if (userRole === 'admin') {
                    // Admin fetches for all users
                    usersToFetchFor = mappedUsers;
                } else if (loggedInUserFromList) {
                    // Member fetches only for themselves
                    usersToFetchFor = [loggedInUserFromList];
                } else {
                    // Should not happen if role is assigned, but as a safeguard
                    usersToFetchFor = [];
                }

                const emailPromises = usersToFetchFor.map(user => GoogleWorkspaceService.getEmailsForUser(user.email));
                const emailsPerUser = await Promise.all(emailPromises);
                const allEmails = emailsPerUser.flat();

                processEmailsToContacts(allEmails, mappedUsers);

            } catch (err: any) {
                console.error("Failed to fetch workspace data:", err);
                setAppError(`Error fetching data: ${err.message || 'Please check your permissions and try again.'}`);
            } finally {
                setIsLoadingData(false);
            }
        };

        fetchWorkspaceData();
    }, [isLoggedIn, gapiReady]);

    const processEmailsToContacts = (emails: Email[], workspaceUsers: User[]) => {
        const contactsMap = new Map<string, Contact>();

        emails.forEach(email => {
            const externalParticipants = [email.from, ...email.to].filter(
                p => p.email && !workspaceUsers.some(u => u.email === p.email)
            );

            externalParticipants.forEach(participant => {
                if (!participant.email) return; // Skip if participant has no email
                
                if (!contactsMap.has(participant.email)) {
                    contactsMap.set(participant.email, {
                        id: participant.email,
                        name: participant.name || participant.email.split('@')[0],
                        email: participant.email,
                        title: 'Unknown',
                        company: participant.email.split('@')[1],
                        associatedEmails: [],
                        users: new Set<string>(),
                    });
                }
                const contact = contactsMap.get(participant.email);
                if (contact) {
                    contact.associatedEmails.push(email);
                    const internalUser = workspaceUsers.find(u => u.email === email.user);
                    if (internalUser) {
                        contact.users.add(internalUser.id);
                    }
                }
            });
        });
        const contacts = Array.from(contactsMap.values());
        setAllContacts(contacts);
    };

    const handleViewSummary = useCallback(async (contact: Contact) => {
        // NOTE FOR FUTURE REVISION:
        // The current implementation generates summaries on-demand when a user clicks the "AI Summary" button.
        // This is efficient for API usage but can introduce a slight delay for the user.
        // A potential upgrade would be a "smarter" pre-caching or background summarization mechanism.
        // This could involve:
        // 1. Summarizing conversations in the background after the initial data load.
        // 2. Prioritizing summaries for the most recent or active contacts.
        // 3. Storing summaries locally (e.g., in localStorage or a more robust cache) to persist them.
        // This would provide a faster user experience but would require careful management of API costs and rate limits.
        
        setSelectedContact(contact);
        if (summaries[contact.id]) return;

        setIsSummaryLoading(true);
        setSummaryError(null);
        try {
            const summary = await generateContactSummary(contact.name, contact.associatedEmails);
            setSummaries(prev => ({ ...prev, [contact.id]: summary }));
        } catch (err) {
            console.error("Failed to generate summary:", err);
            setSummaryError("Sorry, we couldn't generate the summary. Please try again.");
        } finally {
            setIsSummaryLoading(false);
        }
    }, [summaries]);

    const closeModal = () => {
        setSelectedContact(null);
        setSummaryError(null);
    };

    const handleLogin = () => GoogleWorkspaceService.signIn();
    const handleLogout = () => GoogleWorkspaceService.signOut();

    const filteredContacts = useMemo(() => {
        if (currentUser?.role === 'admin' && activeUserId === 'all') return allContacts;
        return allContacts.filter(contact => contact.users.has(activeUserId));
    }, [allContacts, activeUserId, currentUser]);

    if (appError) {
        return (
            <div className="min-h-screen flex items-center justify-center text-center bg-slate-50 p-4">
                <div className="max-w-md bg-white p-8 rounded-lg shadow-lg border border-red-200">
                    <h2 className="text-xl font-semibold text-red-800 mb-4">Application Error</h2>
                    <p className="text-red-700 text-left">{appError}</p>
                </div>
            </div>
        );
    }

    if (!gapiReady) {
        return <div className="min-h-screen flex items-center justify-center">Initializing...</div>;
    }

    if (!isLoggedIn) {
        return <LoginScreen onLogin={handleLogin} />;
    }

    return (
        <div className="min-h-screen font-sans text-slate-800">
            {currentUser && (
                <Header
                    currentUser={currentUser}
                    users={users}
                    activeUserId={activeUserId}
                    setActiveUserId={setActiveUserId}
                    onLogout={handleLogout}
                />
            )}

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {isLoadingData ? (
                    <div className="text-center py-12">Loading workspace data...</div>
                ) : (
                    <ContactTable contacts={filteredContacts} onViewSummary={handleViewSummary} />
                )}
            </main>

            {selectedContact && (
                <SummaryModal
                    isOpen={!!selectedContact}
                    onClose={closeModal}
                    contact={selectedContact}
                    summary={summaries[selectedContact.id]}
                    isLoading={isSummaryLoading}
                    error={summaryError}
                />
            )}
        </div>
    );
};

export default App;
