import { User, Email } from '../types';

export const mockUsers: User[] = [
    { id: 'u1', name: 'Alice', email: 'alice@my-corp.com', role: 'admin' },
    { id: 'u2', name: 'Bob', email: 'bob@my-corp.com', role: 'member' },
    { id: 'u3', name: 'Charlie', email: 'charlie@my-corp.com', role: 'member' },
];

export const mockEmails: Email[] = [
    {
        id: 'e1',
        from: { name: 'David Lee', email: 'david.lee@innovatech.com' },
        to: [{ name: 'Alice', email: 'alice@my-corp.com' }],
        subject: 'Project Alpha Kick-off',
        body: 'Hi Alice, Looking forward to starting Project Alpha. Can we schedule a meeting for next week?',
        date: '2024-07-20T10:00:00Z',
        user: 'alice@my-corp.com'
    },
    {
        id: 'e2',
        from: { name: 'Alice', email: 'alice@my-corp.com' },
        to: [{ name: 'David Lee', email: 'david.lee@innovatech.com' }],
        subject: 'Re: Project Alpha Kick-off',
        body: 'Hi David, Absolutely. How about Tuesday at 2 PM PST? I will send an invite.',
        date: '2024-07-20T11:00:00Z',
        user: 'alice@my-corp.com'
    },
    {
        id: 'e3',
        from: { name: 'Eve Chen', email: 'eve.chen@synergy.co' },
        to: [{ name: 'Bob', email: 'bob@my-corp.com' }],
        subject: 'Q3 Partnership Proposal',
        body: 'Hi Bob, Please find attached our proposal for the Q3 partnership. Let me know your thoughts.',
        date: '2024-07-21T09:30:00Z',
        user: 'bob@my-corp.com'
    },
    {
        id: 'e4',
        from: { name: 'Bob', email: 'bob@my-corp.com' },
        to: [{ name: 'Eve Chen', email: 'eve.chen@synergy.co' }],
        subject: 'Re: Q3 Partnership Proposal',
        body: 'Thanks, Eve. This looks promising. My team will review it and I will get back to you by the end of the week.',
        date: '2024-07-21T14:00:00Z',
        user: 'bob@my-corp.com'
    },
    {
        id: 'e5',
        from: { name: 'Frank Miller', email: 'frank.m@quantumsolutions.io' },
        to: [{ name: 'Charlie', email: 'charlie@my-corp.com' }, { name: 'Alice', email: 'alice@my-corp.com' }],
        subject: 'Urgent: API Integration Issue',
        body: 'Hi team, We are seeing some errors with the API integration. Can someone from your side take a look?',
        date: '2024-07-22T15:00:00Z',
        user: 'charlie@my-corp.com'
    },
    {
        id: 'e6',
        from: { name: 'Alice', email: 'alice@my-corp.com' },
        to: [{ name: 'Frank Miller', email: 'frank.m@quantumsolutions.io' }],
        subject: 'Re: Urgent: API Integration Issue',
        body: 'Hi Frank, I am on it. I have looped in our lead engineer. Will update you shortly.',
        date: '2024-07-22T15:15:00Z',
        user: 'alice@my-corp.com'
    },
    {
        id: 'e7',
        from: { name: 'David Lee', email: 'david.lee@innovatech.com' },
        to: [{ name: 'Alice', email: 'alice@my-corp.com' }],
        subject: 'Re: Project Alpha Kick-off',
        body: 'Tuesday at 2 PM PST works perfectly. Thanks!',
        date: '2024-07-20T11:30:00Z',
        user: 'alice@my-corp.com'
    },
     {
        id: 'e8',
        from: { name: 'Grace Hopper', email: 'grace@nextgen-analytics.com' },
        to: [{ name: 'Bob', email: 'bob@my-corp.com' }],
        subject: 'Follow-up on our call',
        body: 'Hi Bob, Great chatting with you earlier. As discussed, I\'ve attached the case study on our latest product. Looking forward to hearing your feedback.',
        date: '2024-07-23T11:00:00Z',
        user: 'bob@my-corp.com'
    },
];