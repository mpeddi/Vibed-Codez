
import React from 'react';
import { User } from '../types';

interface HeaderProps {
    currentUser: User;
    users: User[];
    activeUserId: string;
    setActiveUserId: (id: string) => void;
    onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentUser, users, activeUserId, setActiveUserId, onLogout }) => {
    return (
        <header className="bg-white shadow-md sticky top-0 z-10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Workspace AI CRM</h1>
                    <p className="text-slate-500">Automatically generated contacts from your organization's emails.</p>
                </div>
                <div className="flex items-center gap-4">
                     <div className="text-right">
                        <div className="text-sm font-medium text-slate-900">{currentUser.name}</div>
                        <div className="text-xs text-slate-500">{currentUser.email}</div>
                    </div>
                    <button 
                        onClick={onLogout}
                        className="rounded-md bg-white px-2.5 py-1.5 text-sm font-semibold text-slate-900 shadow-sm ring-1 ring-inset ring-slate-300 hover:bg-slate-50"
                    >
                        Sign Out
                    </button>
                </div>
            </div>
            {currentUser.role === 'admin' && (
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-slate-200">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        <button
                            onClick={() => setActiveUserId('all')}
                            className={`${
                                activeUserId === 'all'
                                    ? 'border-indigo-500 text-indigo-600'
                                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                        >
                            All Contacts
                        </button>
                        {users.map(user => (
                            <button
                                key={user.id}
                                onClick={() => setActiveUserId(user.id)}
                                className={`${
                                    activeUserId === user.id
                                        ? 'border-indigo-500 text-indigo-600'
                                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                            >
                                {user.name}
                            </button>
                        ))}
                    </nav>
                </div>
            )}
        </header>
    );
};
