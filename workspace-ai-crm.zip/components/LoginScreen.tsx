import React from 'react';
import { GoogleIcon } from './icons/GoogleIcon';

interface LoginScreenProps {
    onLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
    return (
        <div className="flex items-center justify-center min-h-screen bg-slate-100">
            <div className="text-center p-8 bg-white shadow-xl rounded-lg max-w-md w-full">
                <h1 className="text-3xl font-bold text-slate-900 mb-2">Workspace AI CRM</h1>
                <p className="text-slate-500 mb-8">Sign in to access your organization's contacts.</p>
                <button
                    onClick={onLogin}
                    type="button"
                    className="w-full inline-flex justify-center items-center gap-x-3 rounded-md bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-inset ring-slate-300 hover:bg-slate-50 transition-colors"
                >
                    <GoogleIcon className="h-5 w-5" />
                    Sign in with Google
                </button>
            </div>
        </div>
    );
};