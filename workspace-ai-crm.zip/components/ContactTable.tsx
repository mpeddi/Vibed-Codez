
import React from 'react';
import { Contact } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';

interface ContactTableProps {
    contacts: Contact[];
    onViewSummary: (contact: Contact) => void;
}

export const ContactTable: React.FC<ContactTableProps> = ({ contacts, onViewSummary }) => {
    if (contacts.length === 0) {
        return (
            <div className="text-center py-12 bg-white rounded-lg shadow">
                <h3 className="text-lg font-medium text-slate-700">No contacts found.</h3>
                <p className="text-slate-500 mt-1">Try selecting a different user or check your data source.</p>
            </div>
        )
    }

    return (
        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg bg-white">
            <table className="min-w-full divide-y divide-slate-300">
                <thead className="bg-slate-50">
                    <tr>
                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-slate-900 sm:pl-6">Name</th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-900">Email</th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-900">Company</th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-900">Notes</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                    {contacts.map((contact) => (
                        <tr key={contact.id} className="hover:bg-slate-50">
                            <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">{contact.name}</td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">{contact.email}</td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">{contact.company}</td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">
                                <button
                                    onClick={() => onViewSummary(contact)}
                                    className="inline-flex items-center gap-x-1.5 rounded-md bg-indigo-600 px-2.5 py-1.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 transition-colors"
                                >
                                    <SparklesIcon className="h-4 w-4" />
                                    AI Summary
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};
