
declare const gapi: any;

// Add type definitions for Google Identity Services (GIS) client to resolve namespace errors.
declare namespace google {
    namespace accounts {
        namespace oauth2 {
            interface TokenResponse {
                access_token: string;
                [key: string]: any;
            }

            interface TokenClient {
                requestAccessToken: (options?: { prompt?: string }) => void;
            }

            function initTokenClient(config: {
                client_id: string | undefined;
                scope: string;
                callback: (tokenResponse: TokenResponse | {}) => void;
            }): TokenClient;

            function revoke(accessToken: string, done: () => void): void;
        }
    }
}

import { User, Email, Participant } from '../types';

// These variables are expected to be set in the environment.
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const API_KEY = process.env.API_KEY;

// Scopes required for the application.
// Read users from the directory and read emails from Gmail.
const SCOPES = 'https://www.googleapis.com/auth/admin.directory.user.readonly https://www.googleapis.com/auth/gmail.readonly';

let tokenClient: google.accounts.oauth2.TokenClient | null = null;
let gapiInited = false;
let gisInited = false;

/**
 * Initializes the GAPI client and the Google Identity Services client.
 * This function must be called before any other function in this module.
 * @param {function} onAuthChange - Callback function to be called when auth state changes.
 */
export const initClient = (onAuthChange: (tokenResponse: google.accounts.oauth2.TokenResponse | {}) => void): Promise<void> => {
    // Re-introduce checks for environment variables to provide clear error messages.
    // The Google libraries will fail if these are not provided.
    if (!API_KEY) {
        return Promise.reject(new Error("Configuration Error: The API_KEY environment variable is not set. Please provide a valid Google API Key."));
    }
    if (!GOOGLE_CLIENT_ID) {
        return Promise.reject(new Error("Configuration Error: The GOOGLE_CLIENT_ID environment variable is not set. Please provide a valid Google Client ID."));
    }

    return new Promise((resolve, reject) => {
        gapi.load('client', async () => {
            try {
                await gapi.client.init({
                    apiKey: API_KEY,
                    discoveryDocs: [
                        'https://www.googleapis.com/discovery/v1/apis/admin/directory_v1/rest',
                        'https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest'
                    ],
                });
                gapiInited = true;

                tokenClient = google.accounts.oauth2.initTokenClient({
                    client_id: GOOGLE_CLIENT_ID,
                    scope: SCOPES,
                    callback: onAuthChange,
                });
                gisInited = true;
                resolve();
            } catch (error: any) {
                console.error('GAPI/GIS Initialization Error:', error);
                const details = error?.details || error?.result?.error?.message || JSON.stringify(error);
                reject(new Error(`A problem occurred while initializing Google services: ${details}. Please verify your API Key and Client ID.`));
            }
        });
    });
};

/**
 * Initiates the Google Sign-In flow.
 */
export const signIn = () => {
    if (!tokenClient) {
        throw new Error("GAPI client not initialized.");
    }
    tokenClient.requestAccessToken({ prompt: 'consent' });
};

/**
 * Signs the user out.
 */
export const signOut = () => {
    const token = gapi.client.getToken();
    if (token) {
        google.accounts.oauth2.revoke(token.access_token, () => {
            gapi.client.setToken(null);
        });
    }
};

/**
 * Gets the current user's email address from the GAPI token.
 */
export const getCurrentUserEmail = (): string | null => {
    const token = gapi.client.getToken();
    if (token && (token as any).jwt) { // A bit of a hack to get profile info
        try {
            const payload = JSON.parse(atob((token as any).jwt.split('.')[1]));
            return payload.email || null;
        } catch (e) {
            console.error("Could not parse JWT for email", e);
            return null;
        }
    }
    // Fallback for older token formats if needed, though less likely with GIS
    if (token) {
         // The user's info isn't directly in the access token itself.
         // A proper implementation would call the people API, but for this app's
         // purpose, we will fetch all users and find the match.
    }
    return null; // Should be handled gracefully in App.tsx
}

/**
 * Fetches all users from the Google Workspace account.
 * @returns {Promise<User[]>} A promise that resolves to an array of users.
 */
export const getUsers = async (): Promise<User[]> => {
    try {
        const response = await gapi.client.directory.users.list({
            customer: 'my_customer',
            maxResults: 500, // Adjust as needed
            orderBy: 'email'
        });

        const users = response.result.users || [];
        return users.map((user: any) => ({
            id: user.id,
            name: user.name.fullName,
            email: user.primaryEmail,
        }));
    } catch (err: any) {
        console.error("Error fetching users:", err);
        throw new Error((err as any).result?.error?.message || 'Failed to fetch users from Google Workspace.');
    }
};

// --- Email Fetching and Parsing Helpers ---

const parseParticipant = (headerValue: string): Participant => {
    const match = headerValue.match(/(.*)<(.*)>/);
    if (match) {
        return { name: match[1].trim().replace(/"/g, ''), email: match[2].trim() };
    }
    return { name: headerValue, email: headerValue };
};

const getHeader = (headers: any[], name: string): string => {
    const header = headers.find(h => h.name.toLowerCase() === name.toLowerCase());
    return header ? header.value : '';
};

const base64UrlDecode = (str: string): string => {
    try {
        return atob(str.replace(/-/g, '+').replace(/_/g, '/'));
    } catch (e) {
        console.error('Base64 decode failed:', e);
        return '';
    }
};

const getBody = (payload: any): string => {
    let body = '';
    if (payload.mimeType === 'text/plain' && payload.body.data) {
        body = payload.body.data;
    } else if (payload.parts) {
        for (const part of payload.parts) {
            if (part.mimeType === 'text/plain') {
                body = part.body.data;
                break;
            }
            if (part.parts) { // Recurse for nested parts
                 const nestedBody = getBody(part);
                 if(nestedBody) {
                    body = nestedBody;
                    break;
                 }
            }
        }
    }
    return body ? base64UrlDecode(body) : '';
};


/**
 * Fetches emails for a specific user.
 * @param {string} userEmail - The email address of the user.
 * @returns {Promise<Email[]>} A promise that resolves to an array of emails.
 */
export const getEmailsForUser = async (userEmail: string): Promise<Email[]> => {
    try {
        const response = await gapi.client.gmail.users.messages.list({
            userId: userEmail,
            maxResults: 50, // Fetch recent 50 emails
            q: '-category:(promotions OR social OR forums)'
        });
        const messages = response.result.messages || [];
        if (messages.length === 0) return [];

        const batch = gapi.client.newBatch();
        messages.forEach(message => {
            if (message.id) {
                batch.add(gapi.client.gmail.users.messages.get({ userId: userEmail, id: message.id }));
            }
        });

        const batchResponse = await batch;
        const emailDetails = Object.values((batchResponse as any).result).map((res: any) => res.result);

        return emailDetails.map((msg: any): Email => {
            const headers = msg.payload.headers;
            return {
                id: msg.id,
                from: parseParticipant(getHeader(headers, 'From')),
                to: getHeader(headers, 'To').split(',').map(p => parseParticipant(p.trim())),
                subject: getHeader(headers, 'Subject'),
                body: getBody(msg.payload),
                date: getHeader(headers, 'Date'),
                user: userEmail,
            };
        });
    } catch (err: any) {
        console.error(`Error fetching emails for ${userEmail}:`, err);
        // Don't throw, just return empty array to not fail the whole process
        return [];
    }
};
