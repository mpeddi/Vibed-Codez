import { GoogleGenAI } from "@google/genai";
import { Email } from '../types';

const API_KEY = process.env.API_KEY;

const ai = new GoogleGenAI({ apiKey: API_KEY! });

function formatEmailsForPrompt(emails: Email[]): string {
    return emails
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .map(email => {
            const toList = email.to.map(p => p.email).join(', ');
            return `
---
From: ${email.from.email}
To: ${toList}
Date: ${email.date}
Subject: ${email.subject}

${email.body}
---
`;
        })
        .join('\n');
}

export async function generateContactSummary(contactName: string, emails: Email[]): Promise<string> {
    const formattedConversation = formatEmailsForPrompt(emails);

    const prompt = `
You are a helpful CRM assistant. Your task is to summarize an email conversation with a client.
Based on the following email thread with ${contactName}, provide a concise summary.
The summary should be in markdown format and include:
- A brief overview of the main topics discussed.
- Any key decisions or outcomes.
- Any outstanding action items for either party.

Here is the email thread:
${formattedConversation}

Please provide the summary now.
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        
        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to generate summary from AI model.");
    }
}
