import { UserRole } from "../types";

/**
 * Defines user roles for the Workspace AI CRM.
 * This acts as a simple, file-based access control list.
 * In a production system, this would likely be managed via a database
 * or an admin interface.
 *
 * Roles:
 * - 'admin': Can view data for all users in the organization.
 * - 'member': Can only view their own contacts and interactions.
 *
 * Users not listed here will be denied access.
 */
export const ROLES: Record<string, UserRole> = {
    // IMPORTANT: Replace these with actual user emails from your Google Workspace.
    // Example:
    // 'owner@my-corp.com': 'admin',
    'alice@my-corp.com': 'admin',
    'bob@my-corp.com': 'member',
    'charlie@my-corp.com': 'member',
};

/**
 * Gets the role for a given user email.
 * @param email The email of the user.
 * @returns The user's role ('admin' or 'member'), or null if they are not in the list.
 */
export function getUserRole(email: string | null | undefined): UserRole | null {
    if (!email) {
        return null;
    }
    // Ensure email is matched case-insensitively
    return ROLES[email.toLowerCase()] || null;
}
