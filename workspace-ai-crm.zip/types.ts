
export type UserRole = 'admin' | 'member';

export interface Participant {
    name: string;
    email: string;
}

export interface Email {
  id: string;
  from: Participant;
  to: Participant[];
  subject: string;
  body: string;
  date: string;
  user: string; // email of the user in my org whose mailbox this is in
}

export interface Contact {
  id:string;
  name: string;
  title: string;
  email: string;
  company: string;
  associatedEmails: Email[];
  users: Set<string>; // Set of user IDs this contact has interacted with
}

export interface User {
    id: string;
    name: string;
    email: string;
    role: UserRole | null;
}