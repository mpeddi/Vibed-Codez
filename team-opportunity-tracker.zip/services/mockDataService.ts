
import type { Opportunity, User } from '../types';

const users: User[] = [
    { name: 'Alex Chen', email: 'alex.chen@example.com', avatarUrl: 'https://picsum.photos/seed/alex/100/100' },
    { name: 'Maria Garcia', email: 'maria.garcia@example.com', avatarUrl: 'https://picsum.photos/seed/maria/100/100' },
    { name: 'David Smith', email: 'david.smith@example.com', avatarUrl: 'https://picsum.photos/seed/david/100/100' },
];

const getPastDate = (daysAgo: number): string => {
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    return date.toISOString();
};

export const getMockOpportunities = (): Opportunity[] => {
    return [
        {
            id: 'opp-001',
            companyName: 'Innovate Corp',
            pointPerson: { name: 'Brian Hall', title: 'VP of Engineering', email: 'b.hall@innovate.com' },
            owner: users[0],
            lastActivityDate: getPastDate(5),
            status: 'Active',
            calendarEvent: {
                id: 'cal-001',
                title: 'Innovate Corp - Synergy Meeting',
                date: getPastDate(5),
                participants: ['alex.chen@example.com', 'b.hall@innovate.com'],
                agenda: 'Discuss potential integration of our platform with their new product line.',
            },
            document: {
                id: 'doc-001',
                title: 'Notes: Innovate Corp Synergy',
                summary: 'Brian is very interested in the real-time analytics feature. They need a proposal by EOW. Follow-up on pricing for enterprise tier.',
                url: '#',
            },
        },
        {
            id: 'opp-002',
            companyName: 'Quantum Solutions',
            pointPerson: { name: 'Sarah Jenkins', title: 'Director of Operations', email: 's.jenkins@quantum.com' },
            owner: users[0],
            lastActivityDate: getPastDate(21),
            status: 'Follow-up Needed',
            calendarEvent: {
                id: 'cal-002',
                title: 'Quantum Solutions - Q3 Planning',
                date: getPastDate(21),
                participants: ['alex.chen@example.com', 's.jenkins@quantum.com'],
                agenda: 'Initial discovery call about workflow automation challenges.',
            },
            document: {
                id: 'doc-002',
                title: 'Quantum Solutions - Discovery Call',
                summary: 'Sarah mentioned budget constraints for this quarter but is looking to secure funding for Q4. They are evaluating 3 vendors, including us.',
                url: '#',
            },
        },
        {
            id: 'opp-003',
            companyName: 'DataWeavers Inc.',
            pointPerson: { name: 'Chen Li', title: 'Lead Architect', email: 'c.li@dataweavers.com' },
            owner: users[1],
            lastActivityDate: getPastDate(8),
            status: 'Active',
            calendarEvent: {
                id: 'cal-003',
                title: 'DataWeavers - Technical Demo',
                date: getPastDate(8),
                participants: ['maria.garcia@example.com', 'c.li@dataweavers.com'],
                agenda: 'Deep-dive into our API capabilities and security protocols.',
            },
            document: {
                id: 'doc-003',
                title: 'DataWeavers Demo Follow-up',
                summary: 'The technical team was impressed. They have questions about on-premise deployment options and data sovereignty. Maria to coordinate with our solutions engineer.',
                url: '#',
            },
        },
        {
            id: 'opp-004',
            companyName: 'NextGen Retail',
            pointPerson: { name: 'Emily White', title: 'Product Manager', email: 'e.white@nextgenretail.com' },
            owner: users[2],
            lastActivityDate: getPastDate(35),
            status: 'Follow-up Needed',
            calendarEvent: {
                id: 'cal-004',
                title: 'Intro Call - NextGen Retail',
                date: getPastDate(35),
                participants: ['david.smith@example.com', 'e.white@nextgenretail.com'],
                agenda: 'Exploring partnership opportunities for their new mobile app.',
            },
            document: {
                id: 'doc-004',
                title: 'NextGen Retail - Initial Thoughts',
                summary: 'Emily is the key decision-maker. The conversation was positive, but they went quiet after the initial call. Needs a strong re-engagement strategy.',
                url: '#',
            },
        },
    ];
};
