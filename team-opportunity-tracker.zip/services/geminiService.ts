
import { GoogleGenAI } from "@google/genai";
import type { Opportunity } from '../types';

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. Using mocked API responses.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const generateContentWithFallback = async (prompt: string): Promise<string> => {
    if (!process.env.API_KEY) {
      // Mocked response for environments without an API key
      await new Promise(resolve => setTimeout(resolve, 1000));
      if (prompt.includes("next steps")) {
          return "1. Send a follow-up email summarizing key discussion points.\n2. Schedule a technical deep-dive with their engineering team.\n3. Prepare a customized proposal based on the meeting notes.";
      }
      if (prompt.includes("follow-up email")) {
          return `Subject: Following up on our discussion

Hi [Contact Name],

Hope you're having a great week.

I wanted to follow up on our conversation from a couple of weeks ago regarding [Topic]. I'm still very excited about the potential to collaborate.

Do you have some time next week to reconnect?

Best,
[Your Name]`;
      }
      return "This is a mocked response.";
    }
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Gemini API call failed:", error);
        return "Error: Could not get suggestion from AI.";
    }
};

export const suggestNextSteps = async (opportunity: Opportunity): Promise<string> => {
  const prompt = `
    You are an expert business development assistant. Based on the following opportunity details, suggest 3 concise, actionable next steps. Format the output as a numbered list.

    Opportunity Details:
    - Company: ${opportunity.companyName}
    - Point Person: ${opportunity.pointPerson.name} (${opportunity.pointPerson.title})
    - Last Activity: Meeting on ${new Date(opportunity.lastActivityDate).toLocaleDateString()}
    - Meeting Agenda: "${opportunity.calendarEvent.agenda}"
    - Meeting Notes Summary: "${opportunity.document.summary}"

    Suggest the next steps.
  `;
  return generateContentWithFallback(prompt);
};

export const suggestFollowUp = async (opportunity: Opportunity): Promise<string> => {
  const prompt = `
    You are an expert sales and relationship manager. The following opportunity has not had any activity recently. Draft a polite and effective follow-up email to re-engage the contact. Keep it brief and professional. The goal is to restart the conversation. The email should be ready to copy and paste.

    Opportunity Details:
    - Contact Name: ${opportunity.pointPerson.name}
    - Company: ${opportunity.companyName}
    - Our Last Contact: A meeting on ${new Date(opportunity.lastActivityDate).toLocaleDateString()} to discuss "${opportunity.calendarEvent.agenda}".

    Draft the follow-up email.
  `;
  return generateContentWithFallback(prompt);
};
