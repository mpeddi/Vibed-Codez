
import React from 'react';

interface TagProps {
    status: 'Active' | 'Follow-up Needed' | 'Closed';
}

const Tag: React.FC<TagProps> = ({ status }) => {
    const colorClasses = {
        'Active': 'bg-green-100 text-green-800',
        'Follow-up Needed': 'bg-amber-100 text-amber-800',
        'Closed': 'bg-slate-200 text-slate-800'
    };

    return (
        <span className={`px-3 py-1 text-xs font-bold rounded-full ${colorClasses[status]}`}>
            {status}
        </span>
    );
};

export default Tag;
