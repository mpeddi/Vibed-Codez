
import React, { useContext } from 'react';
import { AuthContext } from '../App';
import { GoogleIcon, BriefcaseIcon } from './icons/Icons';

const LoginScreen: React.FC = () => {
  const authContext = useContext(AuthContext);

  if (!authContext) {
    return null;
  }

  const { login } = authContext;

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-100 to-blue-200">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-2xl text-center transform hover:scale-105 transition-transform duration-300">
        <div className="flex justify-center">
          <div className="bg-brand-primary p-4 rounded-full">
            <BriefcaseIcon className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-brand-dark">
          Opportunity Tracker
        </h1>
        <p className="text-slate-600">
          Sign in with your Google account to sync your calendar and docs, and unlock AI-powered insights.
        </p>
        <button
          onClick={login}
          className="w-full flex items-center justify-center px-4 py-3 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg shadow-sm hover:shadow-md hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary transition-all"
        >
          <GoogleIcon className="w-6 h-6 mr-3" />
          Sign in with Google
        </button>
      </div>
    </div>
  );
};

export default LoginScreen;
