
import React, { useContext } from 'react';
import { AuthContext } from '../App';
import { BriefcaseIcon, LogoutIcon } from './icons/Icons';


const Header: React.FC = () => {
  const authContext = useContext(AuthContext);

  if (!authContext || !authContext.user) {
    return null;
  }
  const { user, logout } = authContext;

  return (
    <header className="bg-white shadow-md sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-4">
            <div className="bg-brand-primary p-2 rounded-lg">
                <BriefcaseIcon className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-brand-dark">Team Opportunity Tracker</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-semibold text-slate-800">{user.name}</p>
              <p className="text-sm text-slate-500">{user.email}</p>
            </div>
            <img className="h-12 w-12 rounded-full object-cover" src={user.avatarUrl} alt="User avatar" />
            <button
              onClick={logout}
              className="p-2 rounded-full text-slate-500 hover:bg-slate-100 hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary transition-colors"
              aria-label="Logout"
            >
              <LogoutIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
