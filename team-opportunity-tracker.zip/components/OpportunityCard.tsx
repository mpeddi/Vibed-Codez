
import React, { useState, useCallback } from 'react';
import type { Opportunity } from '../types';
import { suggestNextSteps, suggestFollowUp } from '../services/geminiService';
import { BuildingIcon, CalendarIcon, DocumentIcon, UserIcon, SparklesIcon, ChevronDownIcon, ClockIcon } from './icons/Icons';
import LoadingSpinner from './shared/LoadingSpinner';
import Tag from './shared/Tag';

interface OpportunityCardProps {
    opportunity: Opportunity;
}

const OpportunityCard: React.FC<OpportunityCardProps> = ({ opportunity }) => {
    const [suggestion, setSuggestion] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isExpanded, setIsExpanded] = useState(false);
    const [suggestionType, setSuggestionType] = useState<'next_steps' | 'follow_up' | null>(null);

    const handleSuggestNextSteps = useCallback(async () => {
        setIsLoading(true);
        setSuggestionType('next_steps');
        const result = await suggestNextSteps(opportunity);
        setSuggestion(result);
        setIsLoading(false);
    }, [opportunity]);

    const handleSuggestFollowUp = useCallback(async () => {
        setIsLoading(true);
        setSuggestionType('follow_up');
        const result = await suggestFollowUp(opportunity);
        setSuggestion(result);
        setIsLoading(false);
    }, [opportunity]);
    
    const timeSince = (date: string) => {
        const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return `${Math.floor(interval)} years ago`;
        interval = seconds / 2592000;
        if (interval > 1) return `${Math.floor(interval)} months ago`;
        interval = seconds / 86400;
        if (interval > 1) return `${Math.floor(interval)} days ago`;
        interval = seconds / 3600;
        if (interval > 1) return `${Math.floor(interval)} hours ago`;
        interval = seconds / 60;
        if (interval > 1) return `${Math.floor(interval)} minutes ago`;
        return `${Math.floor(seconds)} seconds ago`;
    };

    return (
        <div className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 flex flex-col">
            <div className="p-6 flex-grow">
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <div className="flex items-center gap-2">
                           <BuildingIcon className="w-6 h-6 text-slate-400" />
                           <h3 className="text-xl font-bold text-brand-dark">{opportunity.companyName}</h3>
                        </div>
                        <p className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                            <UserIcon className="w-4 h-4" /> 
                            {opportunity.pointPerson.name}, <span className="italic">{opportunity.pointPerson.title}</span>
                        </p>
                    </div>
                    <Tag status={opportunity.status} />
                </div>

                <div className="space-y-3 text-sm text-slate-700">
                     <div className="flex items-center gap-3">
                        <ClockIcon className="w-5 h-5 text-slate-400 flex-shrink-0" />
                        <div><strong>Last Activity:</strong> {timeSince(opportunity.lastActivityDate)}</div>
                     </div>
                     <div className="flex items-start gap-3">
                        <CalendarIcon className="w-5 h-5 text-slate-400 flex-shrink-0 mt-0.5" />
                        <div><strong>Event:</strong> {opportunity.calendarEvent.title}</div>
                     </div>
                     <div className="flex items-center gap-3">
                         <img src={opportunity.owner.avatarUrl} alt={opportunity.owner.name} className="w-6 h-6 rounded-full"/>
                         <div><strong>Owner:</strong> {opportunity.owner.name}</div>
                     </div>
                </div>

                <div className="mt-4">
                    <button onClick={() => setIsExpanded(!isExpanded)} className="flex items-center text-sm font-semibold text-brand-secondary hover:text-brand-dark">
                        Details
                        <ChevronDownIcon className={`w-5 h-5 ml-1 transform transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                    </button>
                    {isExpanded && (
                         <div className="mt-3 p-4 bg-slate-50 rounded-lg text-sm space-y-3 animate-fade-in">
                            <p><strong>Agenda:</strong> {opportunity.calendarEvent.agenda}</p>
                            <p><strong>Notes Summary:</strong> {opportunity.document.summary}</p>
                            <a href={opportunity.document.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-brand-secondary hover:underline font-semibold">
                                <DocumentIcon className="w-4 h-4" /> View Full Notes
                            </a>
                        </div>
                    )}
                </div>
            </div>

            <div className="border-t border-slate-200 p-4 bg-slate-50/50 rounded-b-xl">
                 {(isLoading || suggestion) && (
                    <div className="p-4 mb-4 bg-brand-light rounded-lg text-brand-dark min-h-[100px]">
                        <h4 className="font-bold mb-2 flex items-center gap-2">
                            <SparklesIcon className="w-5 h-5 text-brand-primary" />
                            {suggestionType === 'next_steps' ? 'Suggested Next Steps' : 'Suggested Follow-up'}
                        </h4>
                        {isLoading ? (
                            <div className="flex items-center justify-center h-full">
                               <LoadingSpinner />
                            </div>
                        ) : (
                            <div className="text-sm whitespace-pre-wrap font-mono bg-white p-3 rounded-md shadow-inner">{suggestion}</div>
                        )}
                    </div>
                 )}

                <div className="flex gap-2 justify-end">
                    <button onClick={handleSuggestNextSteps} disabled={isLoading} className="flex-1 text-sm flex items-center justify-center gap-2 px-3 py-2 font-semibold text-brand-primary bg-blue-100 rounded-lg hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
                        <SparklesIcon className="w-4 h-4" /> Next Steps
                    </button>
                    {opportunity.status === 'Follow-up Needed' && (
                        <button onClick={handleSuggestFollowUp} disabled={isLoading} className="flex-1 text-sm flex items-center justify-center gap-2 px-3 py-2 font-semibold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
                            <SparklesIcon className="w-4 h-4" /> Draft Follow-up
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default OpportunityCard;
