
import React, { useState, useEffect, useContext } from 'react';
import { getMockOpportunities } from '../services/mockDataService';
import type { Opportunity } from '../types';
import { AuthContext } from '../App';
import OpportunityCard from './OpportunityCard';

type ViewMode = 'my' | 'team';

const Dashboard: React.FC = () => {
    const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
    const [viewMode, setViewMode] = useState<ViewMode>('my');
    const authContext = useContext(AuthContext);

    useEffect(() => {
        const data = getMockOpportunities();
        setOpportunities(data);
    }, []);

    const filteredOpportunities = opportunities.filter(op => {
        if (viewMode === 'my') {
            return op.owner.email === authContext?.user?.email;
        }
        return true; // 'team' view shows all
    }).sort((a, b) => new Date(b.lastActivityDate).getTime() - new Date(a.lastActivityDate).getTime());

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
                <h2 className="text-3xl font-bold text-slate-900">Opportunities Dashboard</h2>
                <div className="flex p-1 bg-slate-200 rounded-lg">
                    <button
                        onClick={() => setViewMode('my')}
                        className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${viewMode === 'my' ? 'bg-white text-brand-primary shadow' : 'text-slate-600 hover:bg-slate-300'}`}
                    >
                        My Opportunities
                    </button>
                    <button
                        onClick={() => setViewMode('team')}
                        className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${viewMode === 'team' ? 'bg-white text-brand-primary shadow' : 'text-slate-600 hover:bg-slate-300'}`}
                    >
                        Team View
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredOpportunities.map(op => (
                    <OpportunityCard key={op.id} opportunity={op} />
                ))}
            </div>
        </div>
    );
};

export default Dashboard;
