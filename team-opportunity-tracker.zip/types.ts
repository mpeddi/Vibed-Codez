
export interface User {
  name: string;
  email: string;
  avatarUrl: string;
}

export interface PointPerson {
  name: string;
  title: string;
  email: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  participants: string[];
  agenda: string;
}

export interface GoogleDoc {
  id: string;
  title: string;
  summary: string;
  url: string;
}

export interface Opportunity {
  id: string;
  companyName: string;
  pointPerson: PointPerson;
  owner: User;
  lastActivityDate: string;
  status: 'Active' | 'Follow-up Needed' | 'Closed';
  calendarEvent: CalendarEvent;
  document: GoogleDoc;
}
