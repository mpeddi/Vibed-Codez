
import React, { useState, useCallback, useMemo } from 'react';
import type { User } from './types';
import LoginScreen from './components/LoginScreen';
import Dashboard from './components/Dashboard';
import Header from './components/Header';

export const AuthContext = React.createContext<{
  user: User | null;
  login: () => void;
  logout: () => void;
} | null>(null);

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback(() => {
    setUser({
      name: 'Alex Chen',
      email: 'alex.chen@example.com',
      avatarUrl: 'https://picsum.photos/seed/alex/100/100',
    });
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const authContextValue = useMemo(() => ({ user, login, logout }), [user, login, logout]);

  return (
    <AuthContext.Provider value={authContextValue}>
      <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
        {user ? (
          <>
            <Header />
            <main>
              <Dashboard />
            </main>
          </>
        ) : (
          <LoginScreen />
        )}
      </div>
    </AuthContext.Provider>
  );
};

export default App;
